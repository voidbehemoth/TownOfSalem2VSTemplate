# Town of Salem 2 Mod Template
An (unofficial) Visual Studio template for an unofficial modloader.
## How To Use
1. Install Visual Studio and .NET
2. Either import one of the pre-packaged templates in releases or manually set it up using the template wizard.
3. Create a new project using the template. The project name will be the name of the mod.
4. Modify the .modinfo file to your liking.
